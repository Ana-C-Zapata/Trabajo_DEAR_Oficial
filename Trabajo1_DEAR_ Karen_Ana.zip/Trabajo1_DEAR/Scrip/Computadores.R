
#Librerías usadas
library(GGally)
library(ggplot2)
library(GGally)
library(RColorBrewer)


#Clasificación de variables:
Computadores$Marca <- as.factor(Computadores$Marca)
Computadores$Modelo <- as.factor(Computadores$Modelo)
Computadores$Procesador <- as.factor(Computadores$Procesador)
Computadores$RAM <- as.numeric(Computadores$RAM)
Computadores$Almacenamiento <- as.numeric(Computadores$Almacenamiento)
Computadores$`Tamaño de pantalla` <- as.numeric(Computadores$`Tamaño de pantalla`)
Computadores$`Tarjeta grafica` <- as.factor(Computadores$`Tarjeta grafica`)
Computadores$`Sistema operativo` <- as.factor(Computadores$`Sistema operativo`)
Computadores$Peso <- as.numeric(Computadores$Peso)
Computadores$`Duracion de bateria` <- as.numeric(Computadores$`Duracion de bateria`)
Computadores$Precio <- as.numeric(Computadores$Precio)
Computadores$Garantía <- as.factor(Computadores$Garantía)


#Subconjunto de datos con solo variables cuantitativas
var_cuantitativas <- subset(Computadores, select = c("RAM", "Almacenamiento", 
                                                     "Tamaño de pantalla","Peso",
                                                     "Duracion de bateria",
                                                     "Precio"))

#Subconjunto de datos con solo variables cualitativas
var_cualitativas <- subset(Computadores, select = c("Marca","Modelo","Procesador",
                                                    "Tarjeta grafica",
                                                    "Sistema operativo","Garantía"))

#Análisis Descriptivo - Variables Cuantitativas

summary(Computadores$RAM)
summary(Computadores$Almacenamiento)
summary(Computadores$`Tamaño de pantalla`)
summary(Computadores$Peso)
summary(Computadores$`Duracion de bateria`)
summary(Computadores$Precio)


#Análisis Gráfico - Variables Cuantitativas

#Matriz de dispersión
ggpairs(var_cuantitativas,
        lower = list(continuous = wrap("points", size = 1, alpha = 0.5, color = "palegreen")),
        upper = list(continuous = wrap("cor", size = 4, color = "black")),
        diag = list(continuous = wrap("densityDiag", fill = "lightblue", alpha = 0.5))) +
  labs(title = "Gráfico de pares con correlaciones") +
  theme_minimal(base_size = 12) +
  theme(plot.title = element_text(hjust = 0.5, size = 14),
        axis.text = element_text(size = 10),
        axis.title = element_text(size = 10))

#Gráfico de correlación
ggcorr(var_cuantitativas)

####Analizar ambos gráficos

#Análisis Descriptivo - Variables Cualitativas

table(Computadores$Marca)
table(Computadores$Procesador)
table(Computadores$`Tarjeta grafica`)
table(Computadores$`Sistema operativo`)
table(Computadores$Garantía)
#####AQUÍ SE PUEDE HACER UN ANÁLISIS DE CADA UNA

#Análisis Gráfico - Variables Cualitativas

#Precio vs Marca

ggplot(Computadores, aes(x = Marca, y = Precio)) +
  geom_boxplot(aes(fill = Marca)) +
  labs(title = "Comparación del Precio vs Marca", 
       x = "Marca", 
       y = "Precio") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_brewer(palette = "Set3")

#Precio vs Procesador

ggplot(Computadores, aes(x = Procesador, y = Precio)) +
  geom_boxplot(aes(fill = Procesador)) +
  labs(title = "Comparación del Precio vs Procesador", 
       x = "Procesador", 
       y = "Precio") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_brewer(palette = "Set3")

#Precio vs Tarjeta Gráfica

ggplot(Computadores, aes(x = `Tarjeta grafica`, y = Precio)) +
  geom_boxplot(aes(fill = `Tarjeta grafica`)) +
  labs(title = "Comparación del Precio vs Tarjeta Gráfica", 
       x = "Tarjeta Gráfica", 
       y = "Precio") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_brewer(palette = "Set3")

#Precio vs Sistema Operativo

ggplot(Computadores, aes(x = `Sistema operativo`, y = Precio)) +
  geom_boxplot(aes(fill = `Sistema operativo`)) +
  labs(title = "Comparación del Precio vs Sistema Operativo", 
       x = "Sistema Operativo", 
       y = "Precio") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_brewer(palette = "Set3")

#Precio vs Garantía

ggplot(Computadores, aes(x = Garantía, y = Precio)) +
  geom_boxplot(aes(fill = Garantía)) +
  labs(title = "Comparación del Precio vs Garantía", 
       x = "Garantía", 
       y = "Precio") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_brewer(palette = "Set3")

#####Aquí se puede analizar cada gráfico respecto a la variable Respuesta


#5. Análisis exploratorio:

# ANOVA - Precio vs Marca
aovmarca <- aov(Precio ~ Marca, data = Computadores)
summary(aovmarca)

# ANOVA - Precio vs Procesador
aovprocesador <- aov(Precio ~ Procesador, data = Computadores)
summary(aovprocesador)

# ANOVA - Precio vs Tarjeta
aovtarjeta <- aov(Precio ~ `Tarjeta grafica`, data = Computadores)
summary(aovtarjeta)

# ANOVA - Precio vs Sistema
aovsistema <- aov(Precio ~ `Sistema operativo`, data = Computadores)
summary(aovsistema)

# ANOVA - Precio vs Garantía
aovgarantia <- aov(Precio ~ Garantía, data = Computadores)
summary(aovgarantia)


#Modelos:

#Modelo con todas las variables menos el modelo
modelo1 <- lm(Precio ~ RAM + Almacenamiento + Peso + Garantía+ `Tarjeta grafica` + Procesador + `Sistema operativo`+ Marca + `Tamaño de pantalla` + `Duracion de bateria` , data = Computadores)
modelo1
summary(modelo1)
#0.007674

#Modelo por interpretación propia
modelo2 <- lm(Precio ~ Marca + Procesador + `Tarjeta grafica` + RAM + Almacenamiento + `Duracion de bateria`, data = Computadores)
modelo2
summary(modelo2)
#0.00388

#Modelo con transformación (Utilizando indicador de eficiencia energetica)

modelo3 <- lm(Precio ~ Peso + `Duracion de bateria` + RAM + Garantía + Almacenamiento + Procesador + `Sistema operativo`+ Marca + `Tamaño de pantalla`, data = Computadores)
summary(modelo3)
#0.006824

Computadores$eficiencia_energetica <- (Computadores$`Duracion de bateria`/Computadores$Peso)

modelo3_transformado <- lm(Precio ~ eficiencia_energetica + RAM + Garantía + Almacenamiento + Procesador + `Sistema operativo`+ Marca + `Tamaño de pantalla`, data = Computadores)
summary(modelo3_transformado)
#0.006947


#Ver significancia uilizamos el valor p que debe ser menor al nivel de significancia (0.05)
#Hacemos análisis con los dos modelos más "significativos" es decir, modelo 0 y 
#modelo 3.


#Multicolinealidad
library(car)
vif(modelo1)

#Summary modelos: Para todas las variables cialitativas nos va a aparecer el despliege 
#de de lo que se encuentra en la base de datos. Si es número el punto de referencia lo 
#define R, si es letra es la primera letro de abecedario. Estos puntos de referencia
#no aparecen en el summary porque están ocultos en el intercepto y es con quien se compara
#Se compara como cambió el precio cuando comparo el procesardor intel corei 5 con el intel corei 7
#Interpretación: Se comparan los coeficientes (ESTIMATE) volver a hacerl el gráfico del boxplot 
#comparatico del precio con las cualitativas usadas en el modelo para interpretar.
#se miran las medianas. Como está cambiando mi variable respuesta en relación a el valor
#referencia (el valor que no está apareciendo).

#Para interpretar las variables cuantitativas: Por una unidad que aumenta (variable cuantitativa)
#va disminuir o aumentar (según sea el signo) la variable respuesta (Peso). Aquí se debe analizar 
#con lógica para saber si lo que muestra el modelo es coherente o no.


#Gráficar los residuales estandarizados

Computadores$Residuals <- rstandard(modelo1)
plot(Computadores$Precio, Computadores$Residuals) + abline(h=0)

ggplot(Computadores, aes(x=Precio, y=Residuals)) + 
  geom_point() +
  geom_smooth(method=lm , color="red", se=TRUE)


#Para ver la influencia de las variables

#MODELO 1
influence.measures(modelo1)




